package i2t.cideim.custom;

/**
 * Created by Leonardo.
 * Defines the constants for the synchronization intent messages.
 */

public final class BroadcastConstants {

    // Custom intent action for synchronization messages
    public static final String BROADCAST_ACTION = "i2t.cideim.custom.BROADCAST";

    // Custom key for the status "extra" in the synchronization intent
    public static final String EXTENDED_DATA_STATUS = "i2t.cideim.custom.STATUS";

}
